#!/bin/bash
echo "This script is about to run another script."

echo "This script has just run another script."